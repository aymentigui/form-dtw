import type { NextAuthConfig } from "next-auth";

export default {
    providers : [],
}satisfies NextAuthConfig