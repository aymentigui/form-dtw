(()=>{var e={};e.id=562,e.ids=[562],e.modules={96330:e=>{"use strict";e.exports=require("@prisma/client")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},79646:e=>{"use strict";e.exports=require("child_process")},55511:e=>{"use strict";e.exports=require("crypto")},14985:e=>{"use strict";e.exports=require("dns")},94735:e=>{"use strict";e.exports=require("events")},29021:e=>{"use strict";e.exports=require("fs")},81630:e=>{"use strict";e.exports=require("http")},55591:e=>{"use strict";e.exports=require("https")},91645:e=>{"use strict";e.exports=require("net")},21820:e=>{"use strict";e.exports=require("os")},33873:e=>{"use strict";e.exports=require("path")},27910:e=>{"use strict";e.exports=require("stream")},34631:e=>{"use strict";e.exports=require("tls")},79551:e=>{"use strict";e.exports=require("url")},28354:e=>{"use strict";e.exports=require("util")},74075:e=>{"use strict";e.exports=require("zlib")},56077:(e,r,t)=>{"use strict";t.r(r),t.d(r,{patchFetch:()=>m,routeModule:()=>l,serverHooks:()=>v,workAsyncStorage:()=>x,workUnitAsyncStorage:()=>f});var s={};t.r(s),t.d(s,{POST:()=>u});var i=t(42706),o=t(28203),a=t(45994),n=t(39187),d=t(96330),p=t(14702);let c=new d.PrismaClient;async function u(e){console.log("ok");try{let{email:r}=await e.json();if(!r)return n.NextResponse.json({error:"Email is required"},{status:400});if(await c.user.findUnique({where:{email:r}}))return n.NextResponse.json({error:"User with this email already exists"},{status:400});let t=Math.floor(1e5+9e5*Math.random()).toString();await c.verificationCode.create({data:{email:r,code:t,expiresAt:new Date(Date.now()+9e5)}});let s=`
  <!DOCTYPE html>
  <html lang="fr">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Code de v\xe9rification</title>
    <style>
      body {
        font-family: Arial, sans-serif;
        background-color: #f9f9f9;
        margin: 0;
        padding: 0;
      }
      .email-container {
        max-width: 600px;
        margin: 20px auto;
        background: #ffffff;
        border-radius: 8px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        overflow: hidden;
      }
      .email-header {
        background-color: #4CAF50;
        color: #ffffff;
        text-align: center;
        padding: 20px;
      }
      .email-header h1 {
        margin: 0;
        font-size: 24px;
      }
      .email-body {
        padding: 20px;
        color: #333333;
      }
      .email-body p {
        margin: 0 0 10px;
        font-size: 16px;
      }
      .verification-code {
        font-size: 24px;
        font-weight: bold;
        color: #4CAF50;
        text-align: center;
        margin: 20px 0;
      }
      .email-footer {
        background-color: #f1f1f1;
        text-align: center;
        padding: 10px;
        font-size: 12px;
        color: #666666;
      }
    </style>
  </head>
  <body>
    <div class="email-container">
      <div class="email-header">
        <h1>Votre code de v\xe9rification</h1>
      </div>
      <div class="email-body">
        <p>Bonjour,</p>
        <p>Nous avons re\xe7u une demande pour v\xe9rifier votre adresse e-mail. Voici votre code de v\xe9rification :</p>
        <div class="verification-code">${t}</div>
        <p>Ce code est valide pendant les 15 prochaines minutes.</p>
        <p>Si vous n'avez pas fait cette demande, veuillez ignorer cet e-mail.</p>
      </div>
      <div class="email-footer">
        <p>&copy; 2024 Direction des transports de wilaya d'Alger - DTW. Tous droits r\xe9serv\xe9s.</p>
      </div>
    </div>
  </body>
  </html>`;return await (0,p.Z)(r,"Code de v\xe9rification",s),n.NextResponse.json({message:"Code de v\xe9rification envoy\xe9"})}catch(e){return n.NextResponse.json({error:"Failed to process request",details:e.message},{status:500})}}let l=new i.AppRouteRouteModule({definition:{kind:o.RouteKind.APP_ROUTE,page:"/api/send-verification-code/route",pathname:"/api/send-verification-code",filename:"route",bundlePath:"app/api/send-verification-code/route"},resolvedPagePath:"C:\\aymen tigui\\projects\\formulaire\\form3\\form\\src\\app\\api\\send-verification-code\\route.ts",nextConfigOutput:"",userland:s}),{workAsyncStorage:x,workUnitAsyncStorage:f,serverHooks:v}=l;function m(){return(0,a.patchFetch)({workAsyncStorage:x,workUnitAsyncStorage:f})}},96487:()=>{},78335:()=>{},14702:(e,r,t)=>{"use strict";t.d(r,{Z:()=>i});let s=t(98721).createTransport({host:process.env.EMAIL_HOST,port:parseInt(process.env.EMAIL_PORT||"587"),auth:{user:process.env.EMAIL_USER,pass:process.env.EMAIL_PASS}});async function i(e,r,t){await s.sendMail({from:process.env.EMAIL_FROM,to:e,subject:r,html:t})}}};var r=require("../../../webpack-runtime.js");r.C(e);var t=e=>r(r.s=e),s=r.X(0,[638,187,839],()=>t(56077));module.exports=s})();